The files <x>_numbers.txt contain sets of integers.

For example 20_numbers.txt contains 20 integers, one on each line.

You can use any of them as <input_file_to_create_queue>.

You can start with 5_numbers.txt, or 20_numbers.txt to debug your program.

The file 100_test_search.txt contains some numbers to use as
	<input_file_to_check_search>.
So you can run:
./TestSearch 100_numbers.txt 100_test_search.txt

The file 100_test_delete.txt contains some number to use as
	<input_file_to_check_delete>.
So you can run
./TestDelete 100_numbers.txt 100_test_delete.txt

You can also test your program with 1000_numbers.txt and 10000_numbers.txt:
./TestSearch 1000_numbers.txt 1000_test_search.txt
./TestDelete 1000_numbers.txt 1000_test_delete.txt
