(Loops are possible in all graphs)

Edge weights are between [0,100]

Complete graph has every possible edge
Half graph has no edge with less than 50 weight (therefore 50% of a complete graph)
Quarter graph has no edge with less than 75 weight (therefore 25% of a complete graph)